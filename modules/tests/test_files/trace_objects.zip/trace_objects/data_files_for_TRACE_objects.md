data_files_for_TRACE_testing.md

The data should be a single zip file that contains 4 xml and 4 pdf files, and one md file.

Files should reprensent etds of the type


  - id 5030 - Major Professor A (Harry Y. McSween) - student C (Michael B. Norton)
  - id 3673 - Major Professor A (Harry Y. McSween) - student D (Megan Elizabeth Ennis)
  - id 1202 - Major Professor B (Larry A. Taylor)  - student E (Michael Joseph Mellin
  - id 3142 - Major Professor B (Larry A. Taylor)  - student F (Daren W. Schnare)

The content downloaded was downloaded from the TRACE repository and from the oai repository.
All of these materials are available to the public online.

xml from: dlwork.lib.utk.edu://home/oaiadmin/traceharvest/trace-etdms-etdonly

pdf from: http://www.trace.tennessee.edu/

details:

5030
/home/oaiadmin/traceharvest/trace-etdms-etdonly/utk_gradthes-5030.xml
Volumetric Proportion Analyses of Carbonaceous Chondrites.pdf
http://trace.tennessee.edu/utk_gradthes/3684
student:   Michael B. Norton
Professor: Harry Y. McSween

3673
/home/oaiadmin/traceharvest/trace-etdms-etdonly/utk_gradthes-3673.xml
Crystallization Kinetics of Olivine-Phyric Shergottites.pdf
http://trace.tennessee.edu/utk_gradthes/2771/
Student:   Megan Elizabeth Ennis
Professor: Harry Y. McSween

3142 
/home/oaiadmin/traceharvest/trace-etdms-etdonly/utk_gradthes-3142.xml broken
Petrogenesis of Apollo 15 Olivine-Normative and Quartz-Normative.pdf
http://trace.tennessee.edu/utk_gradthes/1789/
Student:   Darren W. Schnare
Professor: Larry A. Taylor

1202
/home/oaiadmin/traceharvest/trace-etdms-etdonly/utk_gradthes-1202.xml
Major and Trace-Element Chemistry of Minerals in Lithologies A an.pdf
http://trace.tennessee.edu/utk_gradthes/170/
Student:   Michael Joseph Mellin
Professor: Lawrence A. Taylor


